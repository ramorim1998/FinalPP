<template>
  <div id="app">
    <div id="nav">
      <router-link to='/'>Livros</router-link> | 
      <router-link to='/editora'>Editora</router-link>
    </div>
    <router-view/>
  </div>
</template>

<script>
// import Livros from './components/livros.vue'
// import Editora from './components/editora.vue'
export default {
  name: 'App',
  
  components: {
    // Livros,
    // Editora
  }
}

</script>

<style>

#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>

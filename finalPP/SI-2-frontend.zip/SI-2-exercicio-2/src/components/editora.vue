<template>
  <div class="container ">
    <h1>Editora</h1>
    <form class="form-group">
        <p>
          <label for="nome">Nome: </label>
          <input v-model="nome" class="input" type="text" id="nome" name="nome" required>
        </p>
        
        <button class="btn btn-success mr-4" v-on:click.stop.prevent="addEditoras">Salvar</button>
        <button class="btn btn-secondary" v-on:click="deleteEditoras" @click.prevent>Limpar</button>
        <br>
        <h3>Lista de editoras</h3>
        <ol v-if="listaEditoras.length>0">
          <li v-for="editora of listaEditoras" :key="editora.nome">
            {{editora.nome}}
          </li>
        </ol>
    </form>
  </div>
</template>

<script>
import editoraService from '@/services/editoraService.js'
export default {
  name: 'App',
  data(){
    return{
      listaEditoras:[],
      nome:''
    }
  },
  components: {

  }, methods:{
      addEditoras(){
        if(this.nome.trim()==='' ){
          return
        }
        var objetc = {
            nome : this.nome,
        }
        editoraService.createEditora(objetc).them(()=>{
          this.listaEditoras.push(objetc)
          this.$eventHub.$emit('addEditora',this.data);

        })
      },
      deleteEditoras(){
        this.listaEditoras = []
      }

  }

}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>

import apiClient from './configService';

export default ({
    getLivros(){
        return apiClient.get('/livros')
    },
    getLivroId(id){
        return apiClient.get('/livros'+id)
    },
    createLivro(livro){
        return apiClient.post('/livros', livro)
    },
    editarLivro(id,livro){
        return apiClient.put('/livros'+id,livro)
    },
    deleteLivro(id){
        return apiClient.delete('/livros'+id)
    }

})
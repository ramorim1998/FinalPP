import apiClient from './configService';

export default ({
    getEditora(){
        return apiClient.get('/editora')
    },
    getEditoraId(id){
        return apiClient.get('/editora'+id)
    },
    createEditora(editora){
        return apiClient.post('/editora', editora)
    },
    editarEditora(id,editora){
        return apiClient.put('/editora'+id,editora)
    },
    deleteEditora(id){
        return apiClient.delete('/editora'+id)

}})
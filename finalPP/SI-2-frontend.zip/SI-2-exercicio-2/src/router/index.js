import Vue from 'vue'
import VueRouter from 'vue-router'
import Livro from '../components/livros.vue'
import Editora from '../components/editora.vue'

Vue.use(VueRouter)

const routes = [
    {
        path: '/',
        name: 'Livro',
        component: Livro
    },
    {
        path: '/editora',
        name: 'Editora',
        component: Editora
    }
]

const router = new VueRouter({
    routes
})

export default router;